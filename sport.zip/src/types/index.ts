export interface Athlete {
  id: string;
  name: string;
  sport: string;
  image: string;
  achievements: string[];
  bio: string;
  born: string;
  medals?: {
    gold?: number;
    silver?: number;
    bronze?: number;
  };
  featured?: boolean;
}

export type SportCategory = {
  id: string;
  name: string;
  icon: string;
};