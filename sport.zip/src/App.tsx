import React, { useState, useEffect } from 'react';
import { athletes } from './data/athletes';
import Header from './components/Header';
import Hero from './components/Hero';
import CategoryFilter from './components/CategoryFilter';
import AthleteGrid from './components/AthleteGrid';
import Newsletter from './components/Newsletter';
import Footer from './components/Footer';

function App() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [filteredAthletes, setFilteredAthletes] = useState(athletes);
  const [featuredAthletes, setFeaturedAthletes] = useState(athletes.filter(athlete => athlete.featured));

  useEffect(() => {
    if (activeCategory === 'all') {
      setFilteredAthletes(athletes);
    } else {
      setFilteredAthletes(athletes.filter(athlete => athlete.sport === activeCategory));
    }
  }, [activeCategory]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header 
        activeCategory={activeCategory} 
        setActiveCategory={setActiveCategory} 
      />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <Hero />
        
        {/* Content Sections */}
        <div className="py-8">
          {/* Featured Athletes Section */}
          {featuredAthletes.length > 0 && activeCategory === 'all' && (
            <AthleteGrid 
              athletes={featuredAthletes} 
              title="Mashhur Sportchilar" 
            />
          )}
          
          {/* Category Filter */}
          <CategoryFilter 
            activeCategory={activeCategory} 
            setActiveCategory={setActiveCategory} 
          />
          
          {/* All Athletes or Filtered by Category */}
          <AthleteGrid 
            athletes={filteredAthletes} 
            title={activeCategory === 'all' ? "Barcha Sportchilar" : "Tanlangan Sport Turi"} 
          />
        </div>
        
        {/* Newsletter Section */}
        <Newsletter />
      </main>
      
      {/* Footer */}
      <Footer />
    </div>
  );
}

export default App;