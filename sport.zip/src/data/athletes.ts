import { Athlete } from '../types';

export const athletes: Athlete[] = [
  {
    id: '1',
    name: 'Abdulaziz Abdullaev',
    sport: 'boxing',
    image: 'https://images.pexels.com/photos/6767435/pexels-photo-6767435.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    achievements: [
      'Olympic Gold Medalist (2021)',
      'World Championship Gold (2019)',
      'Asian Games Champion (2018)'
    ],
    bio: 'Abdulaziz Abdullaev is one of Uzbekistan\'s most decorated boxers, known for his incredible speed and technical ability. His Olympic gold medal victory brought national pride to Uzbekistan.',
    born: 'February 15, 1995',
    medals: {
      gold: 3,
      silver: 1,
      bronze: 0
    },
    featured: true
  },
  {
    id: '2',
    name: 'Oksana Chusovitina',
    sport: 'gymnastics',
    image: 'https://images.pexels.com/photos/4662293/pexels-photo-4662293.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    achievements: [
      'Olympic Silver Medalist (2008)',
      'World Championship Gold (1991)',
      'Asian Games Gold Medalist (2002, 2006)',
      'Competed in 8 Olympic Games'
    ],
    bio: 'Oksana Chusovitina is a legendary gymnast who has competed in a record eight Olympic Games. Her longevity and dedication to the sport have made her an icon in gymnastics worldwide.',
    born: 'June 19, 1975',
    medals: {
      gold: 1,
      silver: 1,
      bronze: 0
    },
    featured: true
  },
  {
    id: '3',
    name: 'Ruslan Nurudinov',
    sport: 'weightlifting',
    image: 'https://images.pexels.com/photos/1431283/pexels-photo-1431283.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    achievements: [
      'Olympic Gold Medalist (2016)',
      'World Championship Silver (2013)',
      'Asian Games Gold Medalist (2014)'
    ],
    bio: 'Ruslan Nurudinov, known as the "Pride of Uzbekistan," has established himself as one of the world\'s premier weightlifters. His Olympic gold medal performance broke multiple Olympic records.',
    born: 'November 24, 1991',
    medals: {
      gold: 2,
      silver: 1,
      bronze: 1
    },
    featured: true
  },
  {
    id: '4',
    name: 'Bektemir Melikuziev',
    sport: 'boxing',
    image: 'https://images.pexels.com/photos/4761792/pexels-photo-4761792.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    achievements: [
      'Olympic Silver Medalist (2016)',
      'World Championship Silver (2015)',
      'Asian Championship Gold (2017)'
    ],
    bio: 'Bektemir Melikuziev is a powerful boxer who has dominated the light heavyweight division. His aggressive style and knockout power have made him a fan favorite internationally.',
    born: 'April 8, 1996',
    medals: {
      gold: 1,
      silver: 2,
      bronze: 0
    }
  },
  {
    id: '5',
    name: 'Artur Taymazov',
    sport: 'wrestling',
    image: 'https://images.pexels.com/photos/9398238/pexels-photo-9398238.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    achievements: [
      'Three-time Olympic Gold Medalist (2004, 2008, 2012)',
      'Olympic Silver Medalist (2000)',
      'Five-time World Championship Medalist'
    ],
    bio: 'Artur Taymazov is widely regarded as one of the greatest freestyle wrestlers of all time. His three consecutive Olympic gold medals in the heavyweight division cemented his legendary status.',
    born: 'July 20, 1979',
    medals: {
      gold: 3,
      silver: 1,
      bronze: 0
    },
    featured: true
  },
  {
    id: '6',
    name: 'Hasanboy Dusmatov',
    sport: 'boxing',
    image: 'https://images.pexels.com/photos/6765029/pexels-photo-6765029.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    achievements: [
      'Olympic Gold Medalist (2016)',
      'Val Barker Trophy Winner (2016)',
      'Asian Games Gold Medalist (2018)'
    ],
    bio: 'Hasanboy Dusmatov\'s Olympic victory and subsequent Val Barker Trophy (awarded to the best boxer of the Olympics) established him as one of boxing\'s most skilled technicians in the light flyweight division.',
    born: 'June 24, 1993',
    medals: {
      gold: 2,
      silver: 0,
      bronze: 1
    }
  }
];