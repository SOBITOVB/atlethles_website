import { SportCategory } from '../types';
import { Dumbbell, Box as Boxing, Trophy, Medal, Bike, Target, Minimize as Swimming } from 'lucide-react';

export const categories: SportCategory[] = [
  {
    id: 'all',
    name: 'Barcha Sportchilar',
    icon: Trophy.name
  },
  {
    id: 'boxing',
    name: 'Boks',
    icon: Boxing.name
  },
  {
    id: 'weightlifting',
    name: 'Og\'ir Atletika',
    icon: Dumbbell.name
  },
  {
    id: 'wrestling',
    name: 'Kurash',
    icon: Medal.name
  },
  {
    id: 'gymnastics',
    name: 'Gimnastika',
    icon: Target.name
  },
  {
    id: 'cycling',
    name: 'Velosport',
    icon: Bike.name
  },
  {
    id: 'swimming',
    name: 'Suzish',
    icon: Swimming.name
  }
];