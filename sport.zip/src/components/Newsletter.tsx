import React from 'react';
import { Send } from 'lucide-react';

const Newsletter: React.FC = () => {
  return (
    <div className="bg-gradient-to-r from-blue-800 to-blue-600 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="mb-8 md:mb-0 md:mr-8 max-w-lg">
            <h2 className="text-2xl font-bold mb-4">
              Yangiliklarga obuna bo'ling
            </h2>
            <p className="text-blue-100">
              O'zbekiston sportchilari haqidagi so'nggi yangiliklar, musobaqalar natijalari va qiziqarli ma'lumotlarni olish uchun obuna bo'ling.
            </p>
          </div>
          
          <div className="w-full md:w-auto">
            <form className="flex flex-col sm:flex-row gap-3">
              <input
                type="email"
                placeholder="Email manzilingiz"
                className="px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 text-gray-800 min-w-[280px]"
                required
              />
              <button
                type="submit"
                className="bg-green-500 hover:bg-green-600 transition-colors text-white px-6 py-3 rounded-lg flex items-center justify-center"
              >
                <span className="mr-2">Obuna bo'lish</span>
                <Send size={18} />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Newsletter;