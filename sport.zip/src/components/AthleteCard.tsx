import React from 'react';
import { Athlete } from '../types';
import { Medal } from 'lucide-react';

interface AthleteCardProps {
  athlete: Athlete;
  onClick: () => void;
}

const AthleteCard: React.FC<AthleteCardProps> = ({ athlete, onClick }) => {
  return (
    <div 
      className="group relative rounded-xl overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-[1.02] hover:shadow-xl"
      onClick={onClick}
    >
      {/* Background Image */}
      <div className="aspect-[3/4] w-full">
        <img 
          src={athlete.image} 
          alt={athlete.name} 
          className="w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-110"
        />
      </div>
      
      {/* Overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-t from-blue-900 via-blue-900/40 to-transparent opacity-80 group-hover:opacity-90 transition-opacity duration-300"></div>
      
      {/* Content */}
      <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-6 transition-all duration-300 group-hover:translate-y-0">
        {athlete.featured && (
          <div className="absolute top-4 right-4 bg-green-500 text-white text-xs px-2 py-1 rounded-full">
            Mashhur
          </div>
        )}
        
        <h3 className="text-white text-xl sm:text-2xl font-bold mb-2">{athlete.name}</h3>
        <p className="text-green-300 text-sm uppercase tracking-wider mb-2">{athlete.sport}</p>
        
        {athlete.medals && (
          <div className="flex items-center gap-3 mb-3">
            {athlete.medals.gold && athlete.medals.gold > 0 && (
              <div className="flex items-center">
                <div className="h-4 w-4 rounded-full bg-yellow-400 mr-1"></div>
                <span className="text-white text-sm">{athlete.medals.gold}</span>
              </div>
            )}
            {athlete.medals.silver && athlete.medals.silver > 0 && (
              <div className="flex items-center">
                <div className="h-4 w-4 rounded-full bg-gray-300 mr-1"></div>
                <span className="text-white text-sm">{athlete.medals.silver}</span>
              </div>
            )}
            {athlete.medals.bronze && athlete.medals.bronze > 0 && (
              <div className="flex items-center">
                <div className="h-4 w-4 rounded-full bg-amber-700 mr-1"></div>
                <span className="text-white text-sm">{athlete.medals.bronze}</span>
              </div>
            )}
          </div>
        )}
        
        <div className="text-white/80 text-sm mb-3 line-clamp-2 group-hover:line-clamp-none transition-all duration-300">
          {athlete.achievements[0]}
        </div>
        
        <button className="inline-flex items-center text-sm text-white bg-blue-600 hover:bg-blue-700 rounded-full px-4 py-1.5 transition-colors">
          <Medal className="h-4 w-4 mr-1" />
          <span>Batafsil</span>
        </button>
      </div>
    </div>
  );
};

export default AthleteCard;