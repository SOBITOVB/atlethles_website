import React, { useState } from 'react';
import { Athlete } from '../types';
import AthleteCard from './AthleteCard';
import AthleteDetail from './AthleteDetail';

interface AthleteGridProps {
  athletes: Athlete[];
  title: string;
}

const AthleteGrid: React.FC<AthleteGridProps> = ({ athletes, title }) => {
  const [selectedAthlete, setSelectedAthlete] = useState<Athlete | null>(null);

  return (
    <div className="container mx-auto px-4 py-12">
      <h2 className="text-3xl font-bold text-blue-900 mb-8">{title}</h2>
      
      {athletes.length === 0 ? (
        <div className="py-16 text-center">
          <p className="text-xl text-gray-500">Bu toifada hech qanday sportchi topilmadi.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {athletes.map((athlete) => (
            <AthleteCard 
              key={athlete.id} 
              athlete={athlete} 
              onClick={() => setSelectedAthlete(athlete)}
            />
          ))}
        </div>
      )}
      
      {/* Athlete Detail Modal */}
      <AthleteDetail 
        athlete={selectedAthlete} 
        onClose={() => setSelectedAthlete(null)} 
      />
    </div>
  );
};

export default AthleteGrid;