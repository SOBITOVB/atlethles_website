import React, { useState, useEffect } from 'react';
import { Menu, X, Search } from 'lucide-react';
import { categories } from '../data/categories';

interface HeaderProps {
  setActiveCategory: (category: string) => void;
  activeCategory: string;
}

const Header: React.FC<HeaderProps> = ({ setActiveCategory, activeCategory }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-blue-900 bg-opacity-95 shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-white mr-8">
              O'zbekiston Sportchilari
            </h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            {categories.slice(0, 5).map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`text-white font-medium hover:text-green-400 transition-colors px-2 py-1 ${
                  activeCategory === category.id ? 'border-b-2 border-green-400' : ''
                }`}
              >
                {category.name}
              </button>
            ))}
            <div className="relative ml-4">
              <input
                type="text"
                placeholder="Qidiruv..."
                className="bg-blue-800 bg-opacity-50 text-white pl-10 pr-4 py-2 rounded-full focus:outline-none focus:ring-2 focus:ring-green-400 w-40 transition-all duration-300 focus:w-56"
              />
              <Search className="absolute left-3 top-2.5 text-white/70 h-4 w-4" />
            </div>
          </nav>

          {/* Mobile Menu Button */}
          <button className="md:hidden text-white" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-blue-800">
            <div className="relative mb-4">
              <input
                type="text"
                placeholder="Qidiruv..."
                className="bg-blue-800 bg-opacity-50 text-white pl-10 pr-4 py-2 rounded-full focus:outline-none focus:ring-2 focus:ring-green-400 w-full"
              />
              <Search className="absolute left-3 top-2.5 text-white/70 h-4 w-4" />
            </div>
            <nav className="flex flex-col space-y-3">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => {
                    setActiveCategory(category.id);
                    setIsOpen(false);
                  }}
                  className={`text-white text-left font-medium hover:text-green-400 transition-colors py-2 ${
                    activeCategory === category.id ? 'border-l-4 border-green-400 pl-2' : ''
                  }`}
                >
                  {category.name}
                </button>
              ))}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;