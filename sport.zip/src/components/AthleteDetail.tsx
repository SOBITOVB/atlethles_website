import React, { useRef, useEffect } from 'react';
import { Athlete } from '../types';
import { X, Medal, Calendar, Award } from 'lucide-react';

interface AthleteDetailProps {
  athlete: Athlete | null;
  onClose: () => void;
}

const AthleteDetail: React.FC<AthleteDetailProps> = ({ athlete, onClose }) => {
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (athlete) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    const handleClickOutside = (event: MouseEvent) => {
      if (modalRef.current && !modalRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    const handleEscKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscKey);

    return () => {
      document.body.style.overflow = 'unset';
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscKey);
    };
  }, [athlete, onClose]);

  if (!athlete) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm overflow-y-auto p-4">
      <div
        ref={modalRef}
        className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden animate-fadeIn"
      >
        <div className="relative h-64 sm:h-80 overflow-hidden">
          <img
            src={athlete.image}
            alt={athlete.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-blue-900 via-blue-900/40 to-transparent"></div>
          <button
            onClick={onClose}
            className="absolute top-4 right-4 bg-black/30 hover:bg-black/50 text-white p-2 rounded-full transition-colors"
          >
            <X size={20} />
          </button>
          <div className="absolute bottom-0 left-0 p-6">
            <h2 className="text-3xl font-bold text-white">{athlete.name}</h2>
            <p className="text-green-300 text-lg">{athlete.sport}</p>
          </div>
        </div>

        <div className="p-6 overflow-y-auto max-h-[calc(90vh-20rem)]">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="col-span-2">
              <h3 className="text-xl font-semibold mb-4 text-blue-900">Biografiya</h3>
              <p className="text-gray-700 mb-6">{athlete.bio}</p>

              <h3 className="text-xl font-semibold mb-4 text-blue-900">Yutuqlar</h3>
              <ul className="space-y-3">
                {athlete.achievements.map((achievement, index) => (
                  <li key={index} className="flex items-start">
                    <div className="shrink-0 mt-1">
                      <Award className="h-5 w-5 text-green-600" />
                    </div>
                    <span className="ml-3 text-gray-700">{achievement}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-lg font-semibold mb-4 text-blue-900">Ma'lumot</h3>
              
              <div className="mb-4">
                <div className="flex items-center mb-2">
                  <Calendar className="h-4 w-4 text-blue-600 mr-2" />
                  <span className="text-sm text-gray-600">Tug'ilgan sana:</span>
                </div>
                <p className="text-gray-900 ml-6">{athlete.born}</p>
              </div>
              
              {athlete.medals && (
                <div className="mb-4">
                  <div className="flex items-center mb-2">
                    <Medal className="h-4 w-4 text-blue-600 mr-2" />
                    <span className="text-sm text-gray-600">Medallar:</span>
                  </div>
                  <div className="ml-6 flex flex-col space-y-2">
                    {athlete.medals.gold && athlete.medals.gold > 0 && (
                      <div className="flex items-center">
                        <div className="h-4 w-4 rounded-full bg-yellow-400 mr-2"></div>
                        <span className="text-gray-900">Oltin: {athlete.medals.gold}</span>
                      </div>
                    )}
                    {athlete.medals.silver && athlete.medals.silver > 0 && (
                      <div className="flex items-center">
                        <div className="h-4 w-4 rounded-full bg-gray-300 mr-2"></div>
                        <span className="text-gray-900">Kumush: {athlete.medals.silver}</span>
                      </div>
                    )}
                    {athlete.medals.bronze && athlete.medals.bronze > 0 && (
                      <div className="flex items-center">
                        <div className="h-4 w-4 rounded-full bg-amber-700 mr-2"></div>
                        <span className="text-gray-900">Bronza: {athlete.medals.bronze}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 p-4 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-md transition-colors mr-2"
          >
            Yopish
          </button>
          <button
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md transition-colors"
          >
            To'liq Ma'lumot
          </button>
        </div>
      </div>
    </div>
  );
};

export default AthleteDetail;