import React from 'react';

const Hero: React.FC = () => {
  return (
    <div className="relative h-screen">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: "url('https://images.pexels.com/photos/9482142/pexels-photo-9482142.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')" }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-blue-900/80 via-blue-900/60 to-blue-900/90"></div>
      </div>

      {/* Content */}
      <div className="relative container mx-auto px-4 h-full flex flex-col justify-center items-start">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            O'zbekistonning <span className="text-green-400">Mashxur</span> Sportchilari
          </h1>
          <p className="text-xl text-white/90 mb-8 max-w-2xl">
            O'zbekiston sportining eng yorqin yulduzlari bilan tanishing. Ularning g'alabalari va yutuqlari O'zbekistonni dunyoga tanitdi.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
            <button className="px-8 py-3 bg-green-500 hover:bg-green-600 text-white font-medium rounded-lg transition-colors shadow-lg transform hover:scale-105 duration-200">
              Ko'proq Ma'lumot
            </button>
            <button className="px-8 py-3 bg-transparent hover:bg-white/10 text-white border border-white font-medium rounded-lg transition-all transform hover:scale-105 duration-200">
              Sportchilar Gallereyasi
            </button>
          </div>
          
          {/* Statistics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-16 text-center">
            <div className="bg-white/10 p-4 rounded-lg backdrop-blur-sm">
              <div className="text-3xl font-bold text-green-400">250+</div>
              <div className="text-white/80 mt-2">Olimpiya ishtirokchilari</div>
            </div>
            <div className="bg-white/10 p-4 rounded-lg backdrop-blur-sm">
              <div className="text-3xl font-bold text-green-400">85+</div>
              <div className="text-white/80 mt-2">Olimpiya medallari</div>
            </div>
            <div className="bg-white/10 p-4 rounded-lg backdrop-blur-sm">
              <div className="text-3xl font-bold text-green-400">32</div>
              <div className="text-white/80 mt-2">Jahon chempionlari</div>
            </div>
            <div className="bg-white/10 p-4 rounded-lg backdrop-blur-sm">
              <div className="text-3xl font-bold text-green-400">20+</div>
              <div className="text-white/80 mt-2">Sport turlari</div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex flex-col items-center">
        <span className="text-white/80 text-sm mb-2">Pastga suring</span>
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center p-1">
          <div className="w-1.5 h-1.5 bg-white rounded-full animate-bounce mt-1"></div>
        </div>
      </div>
    </div>
  );
};

export default Hero;