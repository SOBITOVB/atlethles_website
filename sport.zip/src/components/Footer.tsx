import React from 'react';
import { Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-blue-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">O'zbekiston<br />Sportchilari</h3>
            <p className="text-blue-200 mb-4">
              O'zbekistonning mashhur sportchilari haqida ma'lumot beruvchi portal.
              Sportchilarimizning yutuqlari va g'alabalari bilan tanishing.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-green-400 transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-white hover:text-green-400 transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-white hover:text-green-400 transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-white hover:text-green-400 transition-colors">
                <Youtube size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Tezkor havolalar</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-blue-200 hover:text-green-400 transition-colors">Bosh sahifa</a>
              </li>
              <li>
                <a href="#" className="text-blue-200 hover:text-green-400 transition-colors">Sportchilar</a>
              </li>
              <li>
                <a href="#" className="text-blue-200 hover:text-green-400 transition-colors">Yangiliklar</a>
              </li>
              <li>
                <a href="#" className="text-blue-200 hover:text-green-400 transition-colors">Fotogalereya</a>
              </li>
              <li>
                <a href="#" className="text-blue-200 hover:text-green-400 transition-colors">Bog'lanish</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Sport turlari</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-blue-200 hover:text-green-400 transition-colors">Boks</a>
              </li>
              <li>
                <a href="#" className="text-blue-200 hover:text-green-400 transition-colors">Kurash</a>
              </li>
              <li>
                <a href="#" className="text-blue-200 hover:text-green-400 transition-colors">Og'ir atletika</a>
              </li>
              <li>
                <a href="#" className="text-blue-200 hover:text-green-400 transition-colors">Gimnastika</a>
              </li>
              <li>
                <a href="#" className="text-blue-200 hover:text-green-400 transition-colors">Suzish</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Bog'lanish</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 text-green-400 mr-2 mt-0.5" />
                <span className="text-blue-200">Toshkent shahri, O'zbekiston Milliy stadioni</span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 text-green-400 mr-2" />
                <span className="text-blue-200">+998 71 123 45 67</span>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 text-green-400 mr-2" />
                <span className="text-blue-200">info@sportchilar.uz</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-blue-800 mt-12 pt-8 text-center text-blue-300 text-sm">
          <p>&copy; {new Date().getFullYear()} O'zbekiston Sportchilari. Barcha huquqlar himoyalangan.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;